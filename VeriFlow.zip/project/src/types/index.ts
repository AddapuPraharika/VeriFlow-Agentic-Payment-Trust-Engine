export type UserRole = 'reviewer' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar_color: string;
  created_at: string;
}

export type AgentStatus = 'active' | 'suspended';

export interface Agent {
  id: string;
  name: string;
  type: string;
  status: AgentStatus;
  trust_score: number;
  owner_id: string | null;
  created_at: string;
}

export type MerchantRiskLevel = 'low' | 'medium' | 'high';

export interface Merchant {
  id: string;
  name: string;
  category: string;
  country: string;
  risk_level: MerchantRiskLevel;
  created_at: string;
}

export type AuthorizationStatus = 'active' | 'expired' | 'revoked';

export interface Authorization {
  id: string;
  user_id: string;
  agent_id: string;
  max_amount: number;
  currency: string;
  allowed_merchants: string[];
  allowed_categories: string[];
  max_quantity: number;
  purpose: string;
  expires_at: string;
  status: AuthorizationStatus;
  created_at: string;
}

export type TransactionStatus =
  | 'pending'
  | 'approved'
  | 'blocked'
  | 'escalated'
  | 'executed'
  | 'failed';

export interface Transaction {
  id: string;
  authorization_id: string;
  agent_id: string;
  user_id: string;
  merchant_id: string;
  amount: number;
  currency: string;
  quantity: number;
  purpose: string;
  status: TransactionStatus;
  decision: string | null;
  created_at: string;
}

export type DecisionType = 'approved' | 'blocked' | 'escalated';
export type RiskLevelType = 'low' | 'medium' | 'high' | 'critical';

export interface PolicyCheck {
  name: string;
  label: string;
  passed: boolean;
  severity: 'info' | 'warning' | 'critical';
  expected: string;
  actual: string;
  message: string;
}

export interface RiskFactor {
  factor: string;
  label: string;
  weight: number;
  triggered: boolean;
  detail: string;
}

export interface AIAnalysis {
  recommendation: DecisionType;
  confidence: number;
  reasoning: string;
  risk_signals: string[];
  behavioural_notes: string;
  overridden_by_policy: boolean;
}

export interface RiskDecision {
  id: string;
  transaction_id: string;
  decision: DecisionType;
  risk_score: number;
  risk_level: RiskLevelType;
  failed_checks: PolicyCheck[];
  passed_checks: PolicyCheck[];
  explanation: string;
  risk_factors: RiskFactor[];
  ai_analysis: AIAnalysis | null;
  created_at: string;
}

export interface PolicyViolation {
  id: string;
  transaction_id: string;
  check_name: string;
  severity: 'info' | 'warning' | 'critical';
  expected: string;
  actual: string;
  message: string;
  created_at: string;
}

export interface EvidenceRecord {
  id: string;
  transaction_id: string;
  evidence_hash: string;
  payload: EvidencePayload;
  chain_hash: string;
  previous_hash: string;
  verified: boolean;
  created_at: string;
}

export interface EvidencePayload {
  authorization: Authorization;
  agent: Agent;
  user: User;
  merchant: Merchant;
  transaction: Transaction;
  risk_decision: RiskDecision;
  payment_events: PaymentEvent[];
  timestamp: string;
  evidence_hash: string;
}

export type PaymentEventType =
  | 'order_created'
  | 'payment_initiated'
  | 'payment_success'
  | 'payment_failed'
  | 'captured'
  | 'refunded';

export interface PaymentEvent {
  id: string;
  transaction_id: string;
  event_type: PaymentEventType;
  razorpay_order_id: string | null;
  razorpay_payment_id: string | null;
  razorpay_signature: string | null;
  amount: number | null;
  currency: string | null;
  status: string;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface TransactionWithRelations extends Transaction {
  agent?: Agent;
  user?: User;
  merchant?: Merchant;
  authorization?: Authorization;
  risk_decision?: RiskDecision;
  evidence?: EvidenceRecord;
  payment_events?: PaymentEvent[];
  violations?: PolicyViolation[];
}

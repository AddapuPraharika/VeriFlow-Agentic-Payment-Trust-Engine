import type {
  Authorization,
  Agent,
  Merchant,
  Transaction,
  PolicyCheck,
  RiskFactor,
  DecisionType,
  RiskLevelType,
  AIAnalysis,
} from '@/types';
import { aiReason } from '@/lib/aiReasoner';

export interface RiskEvaluationInput {
  authorization: Authorization;
  agent: Agent;
  merchant: Merchant;
  transaction: Transaction;
  recentTransactions: Transaction[];
}

export interface RiskEvaluationResult {
  decision: DecisionType;
  risk_score: number;
  risk_level: RiskLevelType;
  failed_checks: PolicyCheck[];
  passed_checks: PolicyCheck[];
  risk_factors: RiskFactor[];
  explanation: string;
  ai_analysis: AIAnalysis;
}

function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function evaluateRisk(input: RiskEvaluationInput): RiskEvaluationResult {
  const { authorization, agent, merchant, transaction, recentTransactions } = input;

  const checks: PolicyCheck[] = [];
  const riskFactors: RiskFactor[] = [];

  // 0a. Agent identity binding check — verify authorization.agent_id === transaction.agent_id
  const agentIdentityMatches = authorization.agent_id === transaction.agent_id;
  checks.push({
    name: 'agent_identity',
    label: 'Agent Identity Binding',
    passed: agentIdentityMatches,
    severity: 'critical',
    expected: `Authorized agent: ${authorization.agent_id}`,
    actual: `Requesting agent: ${transaction.agent_id}`,
    message: agentIdentityMatches
      ? 'Transaction agent matches the user-authorized agent.'
      : 'Transaction initiated by an unauthorized agent. AGENT_IDENTITY_MISMATCH.',
  });

  if (!agentIdentityMatches) {
    riskFactors.push({
      factor: 'agent_identity_mismatch',
      label: 'Agent Identity Mismatch',
      weight: 100,
      triggered: true,
      detail: `Transaction initiated by "${agent.name}" but the user authorized a different agent.`,
    });
  }

  // 0b. Agent status check — verify agent.status === 'active'
  const agentActive = agent.status === 'active';
  checks.push({
    name: 'agent_active',
    label: 'Agent Active Status',
    passed: agentActive,
    severity: 'critical',
    expected: 'Agent status: active',
    actual: `Agent status: ${agent.status}`,
    message: agentActive
      ? 'Agent is active and permitted to transact.'
      : 'Agent is not active. AGENT_NOT_ACTIVE. Transaction blocked.',
  });

  if (!agentActive) {
    riskFactors.push({
      factor: 'agent_not_active',
      label: 'Agent Not Active',
      weight: 100,
      triggered: true,
      detail: `Agent "${agent.name}" has status "${agent.status}" and cannot initiate transactions.`,
    });
  }

  // 1. Authorization validity check
  const authExpired = new Date(authorization.expires_at) < new Date();
  const authActive = authorization.status === 'active' && !authExpired;
  checks.push({
    name: 'authorization_valid',
    label: 'Authorization Valid',
    passed: authActive,
    severity: 'critical',
    expected: 'Active, non-expired authorization',
    actual: authExpired
      ? `Expired on ${new Date(authorization.expires_at).toLocaleDateString()}`
      : authorization.status,
    message: authActive
      ? 'Authorization is active and within validity period.'
      : authExpired
        ? 'Authorization has expired.'
        : `Authorization status is ${authorization.status}.`,
  });

  if (!authActive) {
    riskFactors.push({
      factor: 'expired_authorization',
      label: 'Expired Authorization',
      weight: 40,
      triggered: true,
      detail: 'The authorization used for this transaction has expired.',
    });
  }

  // 2. Amount limit check
  const amountExceeds = transaction.amount > authorization.max_amount;
  const amountDeviation =
    authorization.max_amount > 0
      ? (transaction.amount - authorization.max_amount) / authorization.max_amount
      : 0;
  checks.push({
    name: 'amount_limit',
    label: 'Amount Within Limit',
    passed: !amountExceeds,
    severity: 'critical',
    expected: `Max ${formatINR(authorization.max_amount)}`,
    actual: formatINR(transaction.amount),
    message: amountExceeds
      ? `Amount exceeds authorized limit by ${formatINR(transaction.amount - authorization.max_amount)}.`
      : 'Amount is within the authorized limit.',
  });

  if (amountExceeds) {
    riskFactors.push({
      factor: 'amount_deviation',
      label: 'Amount Exceeds Limit',
      weight: 50,
      triggered: true,
      detail: `Requested ${formatINR(transaction.amount)} exceeds limit of ${formatINR(authorization.max_amount)} by ${formatINR(transaction.amount - authorization.max_amount)}.`,
    });
  } else if (amountDeviation > 0.8 && amountDeviation <= 1) {
    riskFactors.push({
      factor: 'high_amount_utilization',
      label: 'High Amount Utilization',
      weight: 15,
      triggered: true,
      detail: `Transaction uses ${Math.round(amountDeviation * 100)}% of the authorized limit.`,
    });
  }

  // 3. Merchant check
  const merchantAllowed =
    authorization.allowed_merchants.length === 0 ||
    authorization.allowed_merchants.includes(merchant.name);
  checks.push({
    name: 'merchant_allowed',
    label: 'Merchant Allowed',
    passed: merchantAllowed,
    severity: 'warning',
    expected:
      authorization.allowed_merchants.length > 0
        ? authorization.allowed_merchants.join(', ')
        : 'Any merchant',
    actual: merchant.name,
    message: merchantAllowed
      ? 'Merchant is on the allowed list.'
      : `Merchant "${merchant.name}" is not in the allowed merchants list.`,
  });

  if (!merchantAllowed) {
    riskFactors.push({
      factor: 'merchant_mismatch',
      label: 'Merchant Mismatch',
      weight: 30,
      triggered: true,
      detail: `Merchant "${merchant.name}" is not authorized.`,
    });
  }

  // 4. Category check
  const categoryAllowed =
    authorization.allowed_categories.length === 0 ||
    authorization.allowed_categories.includes(merchant.category);
  checks.push({
    name: 'category_allowed',
    label: 'Category Allowed',
    passed: categoryAllowed,
    severity: 'warning',
    expected:
      authorization.allowed_categories.length > 0
        ? authorization.allowed_categories.join(', ')
        : 'Any category',
    actual: merchant.category,
    message: categoryAllowed
      ? 'Category is on the allowed list.'
      : `Category "${merchant.category}" is not authorized.`,
  });

  if (!categoryAllowed) {
    riskFactors.push({
      factor: 'category_mismatch',
      label: 'Category Mismatch',
      weight: 25,
      triggered: true,
      detail: `Category "${merchant.category}" is not in the allowed categories.`,
    });
  }

  // 5. Currency check
  const currencyMatches = transaction.currency === authorization.currency;
  checks.push({
    name: 'currency_match',
    label: 'Currency Match',
    passed: currencyMatches,
    severity: 'critical',
    expected: authorization.currency,
    actual: transaction.currency,
    message: currencyMatches
      ? 'Currency matches the authorized currency.'
      : `Currency ${transaction.currency} does not match authorized ${authorization.currency}.`,
  });

  if (!currencyMatches) {
    riskFactors.push({
      factor: 'currency_mismatch',
      label: 'Currency Mismatch',
      weight: 35,
      triggered: true,
      detail: `Currency ${transaction.currency} does not match ${authorization.currency}.`,
    });
  }

  // 6. Quantity check
  const quantityExceeds = transaction.quantity > authorization.max_quantity;
  checks.push({
    name: 'quantity_limit',
    label: 'Quantity Within Limit',
    passed: !quantityExceeds,
    severity: 'warning',
    expected: `Max ${authorization.max_quantity}`,
    actual: String(transaction.quantity),
    message: quantityExceeds
      ? `Quantity ${transaction.quantity} exceeds max ${authorization.max_quantity}.`
      : 'Quantity is within the authorized limit.',
  });

  if (quantityExceeds) {
    riskFactors.push({
      factor: 'quantity_exceeded',
      label: 'Quantity Exceeded',
      weight: 20,
      triggered: true,
      detail: `Quantity ${transaction.quantity} exceeds authorized max of ${authorization.max_quantity}.`,
    });
  }

  // 7. Purpose check
  const purposeMatches =
    authorization.purpose === 'general' ||
    authorization.purpose === transaction.purpose ||
    transaction.purpose.includes(authorization.purpose);
  checks.push({
    name: 'purpose_match',
    label: 'Purpose Matches',
    passed: purposeMatches,
    severity: 'info',
    expected: authorization.purpose,
    actual: transaction.purpose,
    message: purposeMatches
      ? 'Transaction purpose aligns with authorization.'
      : `Purpose "${transaction.purpose}" does not match authorized "${authorization.purpose}".`,
  });

  if (!purposeMatches) {
    riskFactors.push({
      factor: 'purpose_mismatch',
      label: 'Purpose Mismatch',
      weight: 15,
      triggered: true,
      detail: `Purpose "${transaction.purpose}" does not match authorized "${authorization.purpose}".`,
    });
  }

  // 8. Merchant risk level check
  if (merchant.risk_level === 'high') {
    riskFactors.push({
      factor: 'high_risk_merchant',
      label: 'High-Risk Merchant',
      weight: 20,
      triggered: true,
      detail: `Merchant "${merchant.name}" is classified as high-risk.`,
    });
  } else if (merchant.risk_level === 'medium') {
    riskFactors.push({
      factor: 'medium_risk_merchant',
      label: 'Medium-Risk Merchant',
      weight: 8,
      triggered: true,
      detail: `Merchant "${merchant.name}" is classified as medium-risk.`,
    });
  }

  // 9. Agent trust score check
  if (agent.trust_score < 60) {
    riskFactors.push({
      factor: 'low_agent_trust',
      label: 'Low Agent Trust Score',
      weight: 15,
      triggered: true,
      detail: `Agent trust score is ${agent.trust_score}, below the 60 threshold.`,
    });
  } else if (agent.trust_score < 75) {
    riskFactors.push({
      factor: 'moderate_agent_trust',
      label: 'Moderate Agent Trust Score',
      weight: 8,
      triggered: true,
      detail: `Agent trust score is ${agent.trust_score}.`,
    });
  }

  // 10. Transaction frequency check (last 1 hour)
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const recentCount = recentTransactions.filter(
    (t) => new Date(t.created_at) > oneHourAgo && t.id !== transaction.id
  ).length;

  if (recentCount >= 5) {
    riskFactors.push({
      factor: 'unusual_frequency',
      label: 'Unusual Transaction Frequency',
      weight: 20,
      triggered: true,
      detail: `${recentCount} transactions from this agent in the last hour.`,
    });
    checks.push({
      name: 'transaction_frequency',
      label: 'Transaction Frequency Normal',
      passed: false,
      severity: 'warning',
      expected: 'Less than 5 transactions per hour',
      actual: `${recentCount} in the last hour`,
      message: `Unusual frequency: ${recentCount} transactions in the last hour.`,
    });
  } else {
    checks.push({
      name: 'transaction_frequency',
      label: 'Transaction Frequency Normal',
      passed: true,
      severity: 'info',
      expected: 'Less than 5 transactions per hour',
      actual: `${recentCount} in the last hour`,
      message: 'Transaction frequency is within normal range.',
    });
  }

  // 11. Repeated failed attempts check
  const recentFailures = recentTransactions.filter(
    (t) =>
      (t.status === 'blocked' || t.status === 'failed') &&
      t.agent_id === transaction.agent_id &&
      t.id !== transaction.id
  ).length;

  if (recentFailures >= 3) {
    riskFactors.push({
      factor: 'repeated_failures',
      label: 'Repeated Failed Attempts',
      weight: 25,
      triggered: true,
      detail: `${recentFailures} failed/blocked attempts by this agent recently.`,
    });
    checks.push({
      name: 'repeated_failures',
      label: 'No Repeated Failed Attempts',
      passed: false,
      severity: 'warning',
      expected: 'Fewer than 3 recent failures',
      actual: `${recentFailures} recent failures`,
      message: `${recentFailures} recent failed/blocked attempts detected.`,
    });
  } else {
    checks.push({
      name: 'repeated_failures',
      label: 'No Repeated Failed Attempts',
      passed: true,
      severity: 'info',
      expected: 'Fewer than 3 recent failures',
      actual: `${recentFailures} recent failures`,
      message: 'No pattern of repeated failures detected.',
    });
  }

  // 12. Unusual amount pattern check
  if (recentTransactions.length >= 3) {
    const amounts = recentTransactions.map((t) => Number(t.amount));
    const avg = amounts.reduce((a, b) => a + b, 0) / amounts.length;
    const deviation = avg > 0 ? Math.abs(transaction.amount - avg) / avg : 0;
    if (deviation > 2) {
      riskFactors.push({
        factor: 'unusual_amount_pattern',
        label: 'Unusual Amount Pattern',
        weight: 15,
        triggered: true,
        detail: `Amount deviates ${Math.round(deviation * 100)}% from the agent's average transaction.`,
      });
    }
  }

  // Calculate risk score
  const triggeredFactors = riskFactors.filter((f) => f.triggered);
  const riskScore = Math.min(
    100,
    triggeredFactors.reduce((sum, f) => sum + f.weight, 0)
  );

  // Determine risk level
  let riskLevel: RiskLevelType;
  if (riskScore >= 70) riskLevel = 'critical';
  else if (riskScore >= 40) riskLevel = 'high';
  else if (riskScore >= 15) riskLevel = 'medium';
  else riskLevel = 'low';

  // Separate checks
  const failedChecks = checks.filter((c) => !c.passed);
  const passedChecks = checks.filter((c) => c.passed);

  // Determine decision: deterministic rules first
  const criticalFailures = failedChecks.filter((c) => c.severity === 'critical');
  const warningFailures = failedChecks.filter((c) => c.severity === 'warning');

  let decision: DecisionType;

  if (criticalFailures.length > 0) {
    // Any critical failure = BLOCKED
    decision = 'blocked';
  } else if (warningFailures.length > 0 || riskLevel === 'high' || riskLevel === 'critical') {
    // Warnings or high risk = ESCALATED
    decision = 'escalated';
  } else {
    // All passed and low/medium risk = APPROVED
    decision = 'approved';
  }

  // Generate explanation
  const explanation = generateExplanation(decision, failedChecks, transaction, authorization);

  // AI Risk Reasoner layer (advisory only — deterministic policy is the final authority)
  const aiAnalysis = aiReason({
    authorization,
    agent,
    merchant,
    transaction,
    policyChecks: checks,
    deterministicDecision: decision,
    riskScore,
    riskLevel,
    recentTransactions,
  });

  return {
    decision,
    risk_score: riskScore,
    risk_level: riskLevel,
    failed_checks: failedChecks,
    passed_checks: passedChecks,
    risk_factors: triggeredFactors,
    explanation,
    ai_analysis: aiAnalysis,
  };
}

function generateExplanation(
  decision: DecisionType,
  failedChecks: PolicyCheck[],
  transaction: Transaction,
  authorization: Authorization
): string {
  if (decision === 'approved') {
    return `APPROVED: Transaction of ${formatINR(Number(transaction.amount))} to "${transaction.purpose}" is within the authorized limit of ${formatINR(Number(authorization.max_amount))}. All policy checks passed.`;
  }

  if (decision === 'blocked') {
    const critical = failedChecks.filter((c) => c.severity === 'critical');
    const reasons = critical.map((c) => c.message).join('; ');
    return `BLOCKED because ${reasons}`;
  }

  // escalated
  const warnings = failedChecks.filter((c) => c.severity === 'warning');
  if (warnings.length > 0) {
    const reasons = warnings.map((c) => c.message).join('; ');
    return `ESCALATED for human review: ${reasons}`;
  }
  return `ESCALATED for human review due to elevated risk indicators requiring manual verification.`;
}

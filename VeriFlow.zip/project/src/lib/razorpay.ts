import type { PaymentEvent, PaymentEventType } from '@/types';

const MOCK_ORDER_PREFIX = 'order_mock_';
const MOCK_PAYMENT_PREFIX = 'pay_mock_';
const MOCK_SIGNATURE_PREFIX = 'sig_mock_';

export interface CreateOrderInput {
  amount: number;
  currency: string;
  notes?: Record<string, string>;
}

export interface CreateOrderResult {
  order_id: string;
  amount: number;
  currency: string;
  status: 'created';
  notes: Record<string, string>;
}

export interface ValidatePaymentInput {
  order_id: string;
  payment_id: string;
  signature: string;
  amount: number;
}

export interface ValidatePaymentResult {
  valid: boolean;
  order_id: string;
  payment_id: string;
}

export interface SimulatePaymentResult {
  success: boolean;
  payment_id: string;
  order_id: string;
  status: 'success' | 'failed';
  error_code?: string;
  error_description?: string;
}

export interface CaptureResult {
  captured: boolean;
  payment_id: string;
  amount: number;
  status: 'captured';
}

export interface RefundResult {
  refunded: boolean;
  refund_id: string;
  payment_id: string;
  amount: number;
  status: 'refunded';
}

export interface PaymentServiceConfig {
  mode: 'mock' | 'sandbox' | 'live';
  keyId: string | null;
  keySecret: string | null;
}

const defaultConfig: PaymentServiceConfig = {
  mode: 'mock',
  keyId: null,
  keySecret: null,
};

function generateId(prefix: string): string {
  const random = Math.random().toString(36).substring(2, 12);
  const time = Date.now().toString(36);
  return `${prefix}${time}${random}`;
}

function generateSignature(orderId: string, paymentId: string): string {
  const raw = `${orderId}|${paymentId}|mock_secret`;
  let hash = 0;
  for (let i = 0; i < raw.length; i++) {
    hash = (hash << 5) - hash + raw.charCodeAt(i);
    hash |= 0;
  }
  return `${MOCK_SIGNATURE_PREFIX}${Math.abs(hash).toString(16)}`;
}

export class RazorpayPaymentService {
  private config: PaymentServiceConfig;

  constructor(config: Partial<PaymentServiceConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
  }

  getMode(): 'mock' | 'sandbox' | 'live' {
    return this.config.mode;
  }

  isMockMode(): boolean {
    return this.config.mode === 'mock';
  }

  updateConfig(config: Partial<PaymentServiceConfig>): void {
    this.config = { ...this.config, ...config };
  }

  getConfig(): PaymentServiceConfig {
    return { ...this.config, keySecret: this.config.keySecret ? '***' : null };
  }

  async createOrder(input: CreateOrderInput): Promise<CreateOrderResult> {
    if (this.config.mode === 'mock') {
      await mockDelay(300);
      return {
        order_id: generateId(MOCK_ORDER_PREFIX),
        amount: input.amount,
        currency: input.currency,
        status: 'created',
        notes: input.notes ?? {},
      };
    }

    // Sandbox/Live mode would call Razorpay API server-side via edge function.
    // Architecture is ready: this is where a fetch to the edge function proxy goes.
    throw new Error(
      `Razorpay ${this.config.mode} mode requires server-side API proxy. Configure an edge function with RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET secrets.`
    );
  }

  async validatePayment(input: ValidatePaymentInput): Promise<ValidatePaymentResult> {
    if (this.config.mode === 'mock') {
      await mockDelay(200);
      const expectedSig = generateSignature(input.order_id, input.payment_id);
      return {
        valid: input.signature === expectedSig,
        order_id: input.order_id,
        payment_id: input.payment_id,
      };
    }

    throw new Error(`Razorpay ${this.config.mode} mode requires server-side validation.`);
  }

  async simulatePayment(
    orderId: string,
    amount: number,
    currency: string,
    forceFail = false
  ): Promise<SimulatePaymentResult> {
    if (this.config.mode !== 'mock') {
      throw new Error('simulatePayment is only available in mock mode.');
    }

    await mockDelay(500);

    if (forceFail) {
      return {
        success: false,
        payment_id: generateId(MOCK_PAYMENT_PREFIX),
        order_id: orderId,
        status: 'failed',
        error_code: 'PAYMENT_DECLINED',
        error_description: 'Simulated payment decline for demo purposes.',
      };
    }

    return {
      success: true,
      payment_id: generateId(MOCK_PAYMENT_PREFIX),
      order_id: orderId,
      status: 'success',
    };
  }

  async capturePayment(paymentId: string, amount: number, currency: string): Promise<CaptureResult> {
    if (this.config.mode === 'mock') {
      await mockDelay(300);
      return {
        captured: true,
        payment_id: paymentId,
        amount,
        status: 'captured',
      };
    }

    throw new Error(`Razorpay ${this.config.mode} mode requires server-side capture.`);
  }

  async refundPayment(paymentId: string, amount: number): Promise<RefundResult> {
    if (this.config.mode === 'mock') {
      await mockDelay(300);
      return {
        refunded: true,
        refund_id: generateId('rfd_mock_'),
        payment_id: paymentId,
        amount,
        status: 'refunded',
      };
    }

    throw new Error(`Razorpay ${this.config.mode} mode requires server-side refund.`);
  }

  buildPaymentEvent(
    transactionId: string,
    eventType: PaymentEventType,
    paymentData: Partial<PaymentEvent>
  ): Omit<PaymentEvent, 'id' | 'created_at'> {
    return {
      transaction_id: transactionId,
      event_type: eventType,
      razorpay_order_id: paymentData.razorpay_order_id ?? null,
      razorpay_payment_id: paymentData.razorpay_payment_id ?? null,
      razorpay_signature: paymentData.razorpay_signature ?? null,
      amount: paymentData.amount ?? null,
      currency: paymentData.currency ?? null,
      status: paymentData.status ?? 'pending',
      metadata: paymentData.metadata ?? {},
    };
  }
}

function mockDelay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export const razorpayService = new RazorpayPaymentService();

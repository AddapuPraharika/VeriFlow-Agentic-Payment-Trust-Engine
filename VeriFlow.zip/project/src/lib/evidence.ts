import type { EvidencePayload, EvidenceRecord } from '@/types';

export async function computeSHA256(data: string): Promise<string> {
  const encoder = new TextEncoder();
  const buffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function computeEvidenceHash(payload: EvidencePayload): Promise<string> {
  const canonical = canonicalizePayload(payload);
  return computeSHA256(canonical);
}

export async function computeChainHash(
  evidenceHash: string,
  previousHash: string
): Promise<string> {
  return computeSHA256(`${previousHash}|${evidenceHash}`);
}

function canonicalizePayload(payload: EvidencePayload): string {
  const ordered: Record<string, unknown> = {
    authorization_id: payload.authorization.id,
    agent_id: payload.agent.id,
    user_id: payload.user.id,
    merchant_id: payload.merchant.id,
    transaction_id: payload.transaction.id,
    amount: payload.transaction.amount,
    currency: payload.transaction.currency,
    quantity: payload.transaction.quantity,
    purpose: payload.transaction.purpose,
    decision: payload.risk_decision.decision,
    risk_score: payload.risk_decision.risk_score,
    risk_level: payload.risk_decision.risk_level,
    failed_checks: payload.risk_decision.failed_checks.map((c) => c.name).sort(),
    passed_checks: payload.risk_decision.passed_checks.map((c) => c.name).sort(),
    payment_events: payload.payment_events.map((e) => ({
      type: e.event_type,
      order_id: e.razorpay_order_id,
      payment_id: e.razorpay_payment_id,
      status: e.status,
    })),
    timestamp: payload.timestamp,
  };
  return JSON.stringify(ordered);
}

export async function verifyEvidenceIntegrity(record: EvidenceRecord): Promise<boolean> {
  if (!record.payload) return false;
  const recomputedHash = await computeEvidenceHash(record.payload);
  return recomputedHash === record.evidence_hash;
}

export async function verifyChainIntegrity(
  records: EvidenceRecord[]
): Promise<{ verified: boolean; brokenAt: string | null }> {
  const sorted = [...records].sort(
    (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
  );

  for (let i = 0; i < sorted.length; i++) {
    const record = sorted[i];
    const hashValid = await verifyEvidenceIntegrity(record);
    if (!hashValid) {
      return { verified: false, brokenAt: record.id };
    }

    if (i > 0) {
      const expectedPrev = sorted[i - 1].evidence_hash;
      if (record.previous_hash !== expectedPrev) {
        return { verified: false, brokenAt: record.id };
      }
      const expectedChain = await computeChainHash(record.evidence_hash, expectedPrev);
      if (record.chain_hash !== expectedChain) {
        return { verified: false, brokenAt: record.id };
      }
    }
  }

  return { verified: true, brokenAt: null };
}

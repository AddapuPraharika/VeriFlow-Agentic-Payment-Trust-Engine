import type {
  Authorization,
  Agent,
  Merchant,
  Transaction,
  PolicyCheck,
  DecisionType,
  RiskLevelType,
} from '@/types';

export interface AIReasoningInput {
  authorization: Authorization;
  agent: Agent;
  merchant: Merchant;
  transaction: Transaction;
  policyChecks: PolicyCheck[];
  deterministicDecision: DecisionType;
  riskScore: number;
  riskLevel: RiskLevelType;
  recentTransactions: Transaction[];
}

export interface AIAnalysis {
  recommendation: DecisionType;
  confidence: number;
  reasoning: string;
  risk_signals: string[];
  behavioural_notes: string;
  overridden_by_policy: boolean;
}

export function aiReason(input: AIReasoningInput): AIAnalysis {
  const { authorization, agent, merchant, transaction, policyChecks, deterministicDecision, riskLevel, recentTransactions } = input;

  const signals: string[] = [];
  const notes: string[] = [];

  const failedChecks = policyChecks.filter((c) => !c.passed);
  const passedChecks = policyChecks.filter((c) => c.passed);

  // Behavioural signal analysis
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const recentCount = recentTransactions.filter(
    (t) => new Date(t.created_at) > oneHourAgo && t.id !== transaction.id
  ).length;

  if (recentCount >= 5) {
    signals.push(`High transaction velocity: ${recentCount} requests in the last hour from "${agent.name}".`);
  }

  if (agent.trust_score < 60) {
    signals.push(`Low trust score (${agent.trust_score}) suggests this agent has a history of problematic behaviour.`);
  }

  if (merchant.risk_level === 'high') {
    signals.push(`Merchant "${merchant.name}" is classified as high-risk with unknown provenance.`);
  }

  const amountUtilization = authorization.max_amount > 0 ? (transaction.amount / authorization.max_amount) * 100 : 0;
  if (amountUtilization > 90 && amountUtilization <= 100) {
    signals.push(`Amount utilizes ${Math.round(amountUtilization)}% of the authorized limit — near-maximum spend pattern.`);
  }

  const recentFailures = recentTransactions.filter(
    (t) => (t.status === 'blocked' || t.status === 'failed') && t.agent_id === agent.id && t.id !== transaction.id
  ).length;
  if (recentFailures >= 3) {
    signals.push(`${recentFailures} recent blocked/failed attempts indicate possible retry-abuse or credential compromise.`);
  }

  // Amount deviation from average
  if (recentTransactions.length >= 3) {
    const amounts = recentTransactions.map((t) => Number(t.amount));
    const avg = amounts.reduce((a, b) => a + b, 0) / amounts.length;
    const deviation = avg > 0 ? Math.abs(transaction.amount - avg) / avg : 0;
    if (deviation > 2) {
      signals.push(`Amount deviates ${Math.round(deviation * 100)}% from the agent's historical average — anomalous spending pattern.`);
    }
  }

  // Agent identity mismatch signal
  if (authorization.agent_id !== transaction.agent_id) {
    signals.push(`Agent identity mismatch: transaction initiated by "${agent.name}" but authorization belongs to a different agent.`);
  }

  // Behavioural notes
  if (signals.length === 0) {
    notes.push('Behavioural profile is consistent with historical agent activity. No anomalous patterns detected.');
  } else {
    notes.push(`${signals.length} behavioural signal(s) detected requiring attention.`);
  }

  // AI recommendation logic (advisory only — never overrides deterministic policy)
  let recommendation: DecisionType;
  let confidence: number;

  if (deterministicDecision === 'blocked') {
    recommendation = 'blocked';
    confidence = 95;
  } else if (signals.length >= 2 || riskLevel === 'high' || riskLevel === 'critical') {
    recommendation = 'escalated';
    confidence = 72;
  } else if (signals.length === 1 || riskLevel === 'medium') {
    recommendation = 'escalated';
    confidence = 65;
  } else {
    recommendation = 'approved';
    confidence = 88;
  }

  const overriddenByPolicy = recommendation !== deterministicDecision && deterministicDecision === 'blocked';

  // Build reasoning text
  const parts: string[] = [];

  if (deterministicDecision === 'blocked') {
    const criticalReasons = failedChecks.filter((c) => c.severity === 'critical').map((c) => c.message);
    parts.push(`AI confirms BLOCK: ${criticalReasons.length} critical policy violation(s) detected.`);
    if (signals.length > 0) {
      parts.push(`Additional behavioural concerns: ${signals.join(' ')}`);
    }
  } else if (deterministicDecision === 'escalated') {
    parts.push(`AI recommends ESCALATION: ${signals.length} risk signal(s) and ${failedChecks.length} policy warning(s) require human review.`);
    if (signals.length > 0) {
      parts.push(`Key signals: ${signals.slice(0, 2).join(' ')}`);
    }
  } else {
    parts.push(`AI concurs with APPROVE: ${passedChecks.length} policy checks passed, no critical behavioural anomalies.`);
    if (signals.length > 0) {
      parts.push(`Minor observations: ${signals.join(' ')}`);
    }
  }

  if (overriddenByPolicy) {
    parts.push('AI recommendation was overridden by mandatory deterministic policy rules.');
  }

  const reasoning = parts.join(' ');

  return {
    recommendation,
    confidence,
    reasoning,
    risk_signals: signals,
    behavioural_notes: notes.join(' '),
    overridden_by_policy: overriddenByPolicy,
  };
}

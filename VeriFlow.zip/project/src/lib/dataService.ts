import { supabase } from '@/lib/supabase';
import { razorpayService } from '@/lib/razorpay';
import { evaluateRisk } from '@/lib/riskEngine';
import { computeEvidenceHash, computeChainHash } from '@/lib/evidence';
import type {
  User,
  Agent,
  Merchant,
  Authorization,
  Transaction,
  RiskDecision,
  PolicyViolation,
  EvidenceRecord,
  PaymentEvent,
  TransactionWithRelations,
  DecisionType,
} from '@/types';

// ---------- Seeding ----------

const SEED_USERS: Omit<User, 'created_at'>[] = [
  { id: 'user-001', name: 'Arjun Mehta', email: 'arjun@veriflow.io', role: 'admin', avatar_color: '#2563eb' },
  { id: 'user-002', name: 'Priya Sharma', email: 'priya@veriflow.io', role: 'reviewer', avatar_color: '#0ea5e9' },
  { id: 'user-003', name: 'Rohan Kapoor', email: 'rohan@veriflow.io', role: 'reviewer', avatar_color: '#059669' },
];

const SEED_AGENTS: Omit<Agent, 'created_at'>[] = [
  { id: 'agent-001', name: 'ShopAssist AI', type: 'shopping', status: 'active', trust_score: 88, owner_id: 'user-001' },
  { id: 'agent-002', name: 'ProcureBot', type: 'procurement', status: 'active', trust_score: 72, owner_id: 'user-002' },
  { id: 'agent-003', name: 'TravelAgent Pro', type: 'travel', status: 'active', trust_score: 65, owner_id: 'user-003' },
  { id: 'agent-004', name: 'QuickPay Agent', type: 'payments', status: 'suspended', trust_score: 45, owner_id: 'user-001' },
];

const SEED_MERCHANTS: Omit<Merchant, 'created_at'>[] = [
  { id: 'merch-001', name: 'TechMart India', category: 'Electronics', country: 'India', risk_level: 'low' },
  { id: 'merch-002', name: 'Laptop Bazaar', category: 'Electronics', country: 'India', risk_level: 'low' },
  { id: 'merch-003', name: 'Global Gadgets', category: 'Electronics', country: 'Singapore', risk_level: 'medium' },
  { id: 'merch-004', name: 'CloudSaaS Inc', category: 'Software', country: 'USA', risk_level: 'medium' },
  { id: 'merch-005', name: 'Office Supplies Co', category: 'Office', country: 'India', risk_level: 'low' },
  { id: 'merch-006', name: 'ShadyDeals Unknown', category: 'Misc', country: 'Unknown', risk_level: 'high' },
  { id: 'merch-007', name: 'BookWorld', category: 'Books', country: 'India', risk_level: 'low' },
  { id: 'merch-008', name: 'MediSupply Pharma', category: 'Healthcare', country: 'India', risk_level: 'medium' },
];

const SEED_AUTHORIZATIONS: Omit<Authorization, 'created_at'>[] = [
  {
    id: 'auth-001', user_id: 'user-001', agent_id: 'agent-001',
    max_amount: 70000, currency: 'INR',
    allowed_merchants: ['TechMart India', 'Laptop Bazaar'],
    allowed_categories: ['Electronics'],
    max_quantity: 2, purpose: 'laptop_purchase',
    expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'active',
  },
  {
    id: 'auth-002', user_id: 'user-002', agent_id: 'agent-002',
    max_amount: 25000, currency: 'INR',
    allowed_merchants: [],
    allowed_categories: ['Office', 'Software'],
    max_quantity: 5, purpose: 'office_supplies',
    expires_at: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'active',
  },
  {
    id: 'auth-003', user_id: 'user-003', agent_id: 'agent-003',
    max_amount: 50000, currency: 'INR',
    allowed_merchants: [],
    allowed_categories: ['Travel'],
    max_quantity: 1, purpose: 'travel_booking',
    expires_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'active',
  },
  {
    id: 'auth-004', user_id: 'user-001', agent_id: 'agent-004',
    max_amount: 15000, currency: 'INR',
    allowed_merchants: [],
    allowed_categories: [],
    max_quantity: 3, purpose: 'general',
    expires_at: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'active',
  },
];

interface SeedTransaction {
  authorization_id: string;
  agent_id: string;
  user_id: string;
  merchant_id: string;
  amount: number;
  currency: string;
  quantity: number;
  purpose: string;
  daysAgo: number;
  forceDecision?: DecisionType;
}

const SEED_TRANSACTIONS: SeedTransaction[] = [
  // Scenario A: Legitimate
  { authorization_id: 'auth-001', agent_id: 'agent-001', user_id: 'user-001', merchant_id: 'merch-001', amount: 64999, currency: 'INR', quantity: 1, purpose: 'laptop_purchase', daysAgo: 5 },
  { authorization_id: 'auth-001', agent_id: 'agent-001', user_id: 'user-001', merchant_id: 'merch-002', amount: 54999, currency: 'INR', quantity: 1, purpose: 'laptop_purchase', daysAgo: 3 },
  // Scenario B: Out of scope (blocked)
  { authorization_id: 'auth-001', agent_id: 'agent-001', user_id: 'user-001', merchant_id: 'merch-001', amount: 82000, currency: 'INR', quantity: 1, purpose: 'laptop_purchase', daysAgo: 2 },
  // Scenario C: Suspicious (escalated)
  { authorization_id: 'auth-002', agent_id: 'agent-002', user_id: 'user-002', merchant_id: 'merch-006', amount: 18000, currency: 'INR', quantity: 2, purpose: 'office_supplies', daysAgo: 1 },
  // Expired auth
  { authorization_id: 'auth-003', agent_id: 'agent-003', user_id: 'user-003', merchant_id: 'merch-004', amount: 35000, currency: 'INR', quantity: 1, purpose: 'travel_booking', daysAgo: 1 },
  // Currency mismatch
  { authorization_id: 'auth-004', agent_id: 'agent-004', user_id: 'user-001', merchant_id: 'merch-003', amount: 12000, currency: 'USD', quantity: 1, purpose: 'general', daysAgo: 4 },
  // Repeated failures
  { authorization_id: 'auth-004', agent_id: 'agent-004', user_id: 'user-001', merchant_id: 'merch-006', amount: 14000, currency: 'INR', quantity: 1, purpose: 'general', daysAgo: 1 },
  { authorization_id: 'auth-004', agent_id: 'agent-004', user_id: 'user-001', merchant_id: 'merch-006', amount: 14000, currency: 'INR', quantity: 1, purpose: 'general', daysAgo: 1 },
  { authorization_id: 'auth-004', agent_id: 'agent-004', user_id: 'user-001', merchant_id: 'merch-006', amount: 14000, currency: 'INR', quantity: 1, purpose: 'general', daysAgo: 1 },
  // Approved office supplies
  { authorization_id: 'auth-002', agent_id: 'agent-002', user_id: 'user-002', merchant_id: 'merch-005', amount: 8500, currency: 'INR', quantity: 3, purpose: 'office_supplies', daysAgo: 6 },
  { authorization_id: 'auth-002', agent_id: 'agent-002', user_id: 'user-002', merchant_id: 'merch-004', amount: 12000, currency: 'INR', quantity: 1, purpose: 'office_supplies', daysAgo: 7 },
  // Approved books
  { authorization_id: 'auth-004', agent_id: 'agent-001', user_id: 'user-001', merchant_id: 'merch-007', amount: 3200, currency: 'INR', quantity: 4, purpose: 'general', daysAgo: 8 },
];

export async function seedDatabase(): Promise<void> {
  // Check if already seeded
  const { count } = await supabase.from('users').select('*', { count: 'exact', head: true });
  if (count && count > 0) return;

  // Insert users
  await supabase.from('users').upsert(SEED_USERS, { onConflict: 'id' });
  await supabase.from('agents').upsert(SEED_AGENTS, { onConflict: 'id' });
  await supabase.from('merchants').upsert(SEED_MERCHANTS, { onConflict: 'id' });
  await supabase.from('authorizations').upsert(SEED_AUTHORIZATIONS, { onConflict: 'id' });

  // Process seed transactions through the risk engine
  for (const seedTx of SEED_TRANSACTIONS) {
    const createdAt = new Date(Date.now() - seedTx.daysAgo * 24 * 60 * 60 * 1000).toISOString();
    const txId = `tx-${seedTx.authorization_id}-${seedTx.merchant_id}-${seedTx.daysAgo}-${Math.random().toString(36).slice(2, 8)}`;

    const { data: auth } = await supabase
      .from('authorizations').select('*').eq('id', seedTx.authorization_id).maybeSingle();
    const { data: agent } = await supabase
      .from('agents').select('*').eq('id', seedTx.agent_id).maybeSingle();
    const { data: merchant } = await supabase
      .from('merchants').select('*').eq('id', seedTx.merchant_id).maybeSingle();

    if (!auth || !agent || !merchant) continue;

    const { data: recentTxs } = await supabase
      .from('transactions').select('*').eq('agent_id', seedTx.agent_id);

    const txRecord: Omit<Transaction, 'id'> = {
      authorization_id: seedTx.authorization_id,
      agent_id: seedTx.agent_id,
      user_id: seedTx.user_id,
      merchant_id: seedTx.merchant_id,
      amount: seedTx.amount,
      currency: seedTx.currency,
      quantity: seedTx.quantity,
      purpose: seedTx.purpose,
      status: 'pending',
      decision: null,
      created_at: createdAt,
    };

    const { data: tx } = await supabase.from('transactions').insert(txRecord).select().maybeSingle();
    if (!tx) continue;

    const evaluation = evaluateRisk({
      authorization: auth as Authorization,
      agent: agent as Agent,
      merchant: merchant as Merchant,
      transaction: tx as Transaction,
      recentTransactions: (recentTxs as Transaction[]) ?? [],
    });

    // Save risk decision
    const riskDecision: Omit<RiskDecision, 'id' | 'created_at'> = {
      transaction_id: tx.id,
      decision: evaluation.decision,
      risk_score: evaluation.risk_score,
      risk_level: evaluation.risk_level,
      failed_checks: evaluation.failed_checks,
      passed_checks: evaluation.passed_checks,
      explanation: evaluation.explanation,
      risk_factors: evaluation.risk_factors,
      ai_analysis: evaluation.ai_analysis,
    };
    await supabase.from('risk_decisions').insert(riskDecision);

    // Save policy violations
    for (const fc of evaluation.failed_checks) {
      const violation: Omit<PolicyViolation, 'id' | 'created_at'> = {
        transaction_id: tx.id,
        check_name: fc.name,
        severity: fc.severity,
        expected: fc.expected,
        actual: fc.actual,
        message: fc.message,
      };
      await supabase.from('policy_violations').insert(violation);
    }

    let paymentEvents: PaymentEvent[] = [];

    if (evaluation.decision === 'approved') {
      // Simulate payment
      const order = await razorpayService.createOrder({
        amount: tx.amount,
        currency: tx.currency,
        notes: { transaction_id: tx.id, purpose: tx.purpose },
      });

      const payment = await razorpayService.simulatePayment(order.order_id, tx.amount, tx.currency);
      const signature = `sig_mock_${order.order_id}_${payment.payment_id}`;

      const capture = await razorpayService.capturePayment(payment.payment_id, tx.amount, tx.currency);

      const eventTypes = [
        { type: 'order_created' as const, data: { razorpay_order_id: order.order_id, status: order.status, amount: order.amount, currency: order.currency } },
        { type: 'payment_initiated' as const, data: { razorpay_order_id: order.order_id, status: 'initiated', amount: tx.amount, currency: tx.currency } },
        { type: 'payment_success' as const, data: { razorpay_order_id: order.order_id, razorpay_payment_id: payment.payment_id, razorpay_signature: signature, status: payment.status, amount: tx.amount, currency: tx.currency } },
        { type: 'captured' as const, data: { razorpay_payment_id: payment.payment_id, status: capture.status, amount: capture.amount, currency: tx.currency } },
      ];

      for (const ev of eventTypes) {
        const eventData = razorpayService.buildPaymentEvent(tx.id, ev.type, ev.data);
        const { data: savedEv } = await supabase.from('payment_events').insert(eventData).select().maybeSingle();
        if (savedEv) paymentEvents.push(savedEv as PaymentEvent);
      }

      await supabase.from('transactions').update({ status: 'executed', decision: evaluation.decision }).eq('id', tx.id);
    } else {
      await supabase.from('transactions').update({ status: evaluation.decision, decision: evaluation.decision }).eq('id', tx.id);
    }

    // Generate evidence record
    const evidencePayload = {
      authorization: auth,
      agent: agent,
      user: (await supabase.from('users').select('*').eq('id', seedTx.user_id).maybeSingle()).data as User,
      merchant: merchant,
      transaction: { ...tx, status: evaluation.decision === 'approved' ? 'executed' : evaluation.decision, decision: evaluation.decision },
      risk_decision: { ...riskDecision, transaction_id: tx.id } as RiskDecision,
      payment_events: paymentEvents,
      timestamp: new Date().toISOString(),
      evidence_hash: '',
    };
    evidencePayload.evidence_hash = await computeEvidenceHash(evidencePayload);

    // Get previous evidence hash for chain
    const { data: prevEvidence } = await supabase
      .from('evidence_records')
      .select('evidence_hash, chain_hash')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const previousHash = prevEvidence?.evidence_hash ?? 'GENESIS';
    const chainHash = await computeChainHash(evidencePayload.evidence_hash, previousHash);

    await supabase.from('evidence_records').insert({
      transaction_id: tx.id,
      evidence_hash: evidencePayload.evidence_hash,
      payload: evidencePayload,
      chain_hash: chainHash,
      previous_hash: previousHash,
      verified: true,
    });
  }
}

// ---------- Queries ----------

export async function getDashboardStats(): Promise<{
  total: number;
  approved: number;
  blocked: number;
  escalated: number;
  executed: number;
  totalValue: number;
  riskExposure: number;
  violations: number;
}> {
  const { data: transactions } = await supabase.from('transactions').select('amount, status');
  const { count: violations } = await supabase
    .from('policy_violations').select('*', { count: 'exact', head: true });

  const txs = transactions ?? [];
  const total = txs.length;
  const approved = txs.filter((t) => t.status === 'approved' || t.status === 'executed').length;
  const blocked = txs.filter((t) => t.status === 'blocked').length;
  const escalated = txs.filter((t) => t.status === 'escalated').length;
  const executed = txs.filter((t) => t.status === 'executed').length;
  const totalValue = txs
    .filter((t) => t.status === 'executed')
    .reduce((sum, t) => sum + Number(t.amount), 0);
  const riskExposure = txs
    .filter((t) => t.status === 'escalated' || t.status === 'blocked')
    .reduce((sum, t) => sum + Number(t.amount), 0);

  return {
    total,
    approved,
    blocked,
    escalated,
    executed,
    totalValue,
    riskExposure,
    violations: violations ?? 0,
  };
}

export async function getRecentTransactions(limit = 10): Promise<TransactionWithRelations[]> {
  const { data: txs } = await supabase
    .from('transactions')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (!txs) return [];
  return enrichTransactions(txs as Transaction[]);
}

export async function getAllTransactions(): Promise<TransactionWithRelations[]> {
  const { data: txs } = await supabase
    .from('transactions')
    .select('*')
    .order('created_at', { ascending: false });

  if (!txs) return [];
  return enrichTransactions(txs as Transaction[]);
}

export async function getTransactionById(id: string): Promise<TransactionWithRelations | null> {
  const { data: tx } = await supabase.from('transactions').select('*').eq('id', id).maybeSingle();
  if (!tx) return null;
  const enriched = await enrichTransactions([tx as Transaction]);
  return enriched[0] ?? null;
}

async function enrichTransactions(txs: Transaction[]): Promise<TransactionWithRelations[]> {
  if (txs.length === 0) return [];

  const agentIds = [...new Set(txs.map((t) => t.agent_id))];
  const userIds = [...new Set(txs.map((t) => t.user_id))];
  const merchantIds = [...new Set(txs.map((t) => t.merchant_id))];
  const authIds = [...new Set(txs.map((t) => t.authorization_id))];
  const txIds = txs.map((t) => t.id);

  const [agentsRes, usersRes, merchantsRes, authsRes, decisionsRes, evidenceRes, eventsRes, violationsRes] =
    await Promise.all([
      supabase.from('agents').select('*').in('id', agentIds),
      supabase.from('users').select('*').in('id', userIds),
      supabase.from('merchants').select('*').in('id', merchantIds),
      supabase.from('authorizations').select('*').in('id', authIds),
      supabase.from('risk_decisions').select('*').in('transaction_id', txIds),
      supabase.from('evidence_records').select('*').in('transaction_id', txIds),
      supabase.from('payment_events').select('*').in('transaction_id', txIds).order('created_at', { ascending: true }),
      supabase.from('policy_violations').select('*').in('transaction_id', txIds),
    ]);

  const agentMap = new Map((agentsRes.data ?? []).map((a) => [a.id, a]));
  const userMap = new Map((usersRes.data ?? []).map((u) => [u.id, u]));
  const merchantMap = new Map((merchantsRes.data ?? []).map((m) => [m.id, m]));
  const authMap = new Map((authsRes.data ?? []).map((a) => [a.id, a]));
  const decisionMap = new Map((decisionsRes.data ?? []).map((d) => [d.transaction_id, d]));
  const evidenceMap = new Map((evidenceRes.data ?? []).map((e) => [e.transaction_id, e]));
  const eventsMap = new Map<string, PaymentEvent[]>();
  for (const ev of (eventsRes.data ?? []) as PaymentEvent[]) {
    if (!eventsMap.has(ev.transaction_id)) eventsMap.set(ev.transaction_id, []);
    eventsMap.get(ev.transaction_id)!.push(ev);
  }
  const violationsMap = new Map<string, PolicyViolation[]>();
  for (const v of (violationsRes.data ?? []) as PolicyViolation[]) {
    if (!violationsMap.has(v.transaction_id)) violationsMap.set(v.transaction_id, []);
    violationsMap.get(v.transaction_id)!.push(v);
  }

  return txs.map((tx) => ({
    ...tx,
    agent: agentMap.get(tx.agent_id) as Agent | undefined,
    user: userMap.get(tx.user_id) as User | undefined,
    merchant: merchantMap.get(tx.merchant_id) as Merchant | undefined,
    authorization: authMap.get(tx.authorization_id) as Authorization | undefined,
    risk_decision: decisionMap.get(tx.id) as RiskDecision | undefined,
    evidence: evidenceMap.get(tx.id) as EvidenceRecord | undefined,
    payment_events: eventsMap.get(tx.id) ?? [],
    violations: violationsMap.get(tx.id) ?? [],
  }));
}

export async function getAllAgents(): Promise<Agent[]> {
  const { data } = await supabase.from('agents').select('*').order('created_at', { ascending: true });
  return (data ?? []) as Agent[];
}

export async function getAllUsers(): Promise<User[]> {
  const { data } = await supabase.from('users').select('*').order('name', { ascending: true });
  return (data ?? []) as User[];
}

export async function getAllMerchants(): Promise<Merchant[]> {
  const { data } = await supabase.from('merchants').select('*').order('name', { ascending: true });
  return (data ?? []) as Merchant[];
}

export async function getAllAuthorizations(): Promise<(Authorization & { agent?: Agent; user?: User })[]> {
  const { data } = await supabase.from('authorizations').select('*').order('created_at', { ascending: false });
  if (!data) return [];
  const auths = data as Authorization[];
  const agentIds = [...new Set(auths.map((a) => a.agent_id))];
  const userIds = [...new Set(auths.map((a) => a.user_id))];
  const [agentsRes, usersRes] = await Promise.all([
    supabase.from('agents').select('*').in('id', agentIds),
    supabase.from('users').select('*').in('id', userIds),
  ]);
  const agentMap = new Map((agentsRes.data ?? []).map((a) => [a.id, a]));
  const userMap = new Map((usersRes.data ?? []).map((u) => [u.id, u]));
  return auths.map((a) => ({
    ...a,
    agent: agentMap.get(a.agent_id) as Agent | undefined,
    user: userMap.get(a.user_id) as User | undefined,
  }));
}

export async function getRiskTrend(days = 14): Promise<{ date: string; approved: number; blocked: number; escalated: number }[]> {
  const { data: txs } = await supabase
    .from('transactions')
    .select('created_at, status')
    .order('created_at', { ascending: true });

  if (!txs) return [];

  const trend: Record<string, { approved: number; blocked: number; escalated: number }> = {};
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().split('T')[0];
    trend[key] = { approved: 0, blocked: 0, escalated: 0 };
  }

  for (const tx of txs) {
    const key = tx.created_at.split('T')[0];
    if (key in trend) {
      if (tx.status === 'executed' || tx.status === 'approved') trend[key].approved++;
      else if (tx.status === 'blocked') trend[key].blocked++;
      else if (tx.status === 'escalated') trend[key].escalated++;
    }
  }

  return Object.entries(trend).map(([date, v]) => ({ date, ...v }));
}

export async function getAgentActivity(): Promise<{ agent: Agent; total: number; approved: number; blocked: number; escalated: number; totalValue: number }[]> {
  const { data: txs } = await supabase.from('transactions').select('agent_id, amount, status');
  const agents = await getAllAgents();
  if (!txs) return agents.map((agent) => ({ agent, total: 0, approved: 0, blocked: 0, escalated: 0, totalValue: 0 }));

  return agents.map((agent) => {
    const agentTxs = txs.filter((t) => t.agent_id === agent.id);
    return {
      agent,
      total: agentTxs.length,
      approved: agentTxs.filter((t) => t.status === 'executed' || t.status === 'approved').length,
      blocked: agentTxs.filter((t) => t.status === 'blocked').length,
      escalated: agentTxs.filter((t) => t.status === 'escalated').length,
      totalValue: agentTxs.filter((t) => t.status === 'executed').reduce((s, t) => s + Number(t.amount), 0),
    };
  });
}

export async function getAllEvidence(): Promise<(EvidenceRecord & { transaction?: Transaction })[]> {
  const { data } = await supabase.from('evidence_records').select('*').order('created_at', { ascending: false });
  if (!data) return [];
  const records = data as EvidenceRecord[];
  const txIds = records.map((r) => r.transaction_id);
  const { data: txs } = await supabase.from('transactions').select('*').in('id', txIds);
  const txMap = new Map((txs ?? []).map((t) => [t.id, t]));
  return records.map((r) => ({ ...r, transaction: txMap.get(r.transaction_id) as Transaction | undefined }));
}

// ---------- Mutations ----------

export interface CreateAuthorizationInput {
  user_id: string;
  agent_id: string;
  max_amount: number;
  currency: string;
  allowed_merchants: string[];
  allowed_categories: string[];
  max_quantity: number;
  purpose: string;
  expires_at: string;
}

export async function createAuthorization(input: CreateAuthorizationInput): Promise<Authorization | null> {
  const { data, error } = await supabase
    .from('authorizations')
    .insert({
      ...input,
      status: 'active',
    })
    .select()
    .maybeSingle();
  if (error) {
    console.error('Failed to create authorization:', error);
    return null;
  }
  return data as Authorization | null;
}

export async function revokeAuthorization(id: string): Promise<void> {
  await supabase.from('authorizations').update({ status: 'revoked' }).eq('id', id);
}

export interface SimulateTransactionInput {
  authorization_id: string;
  agent_id: string;
  merchant_id: string;
  amount: number;
  currency: string;
  quantity: number;
  purpose: string;
}

export interface SimulateTransactionResult {
  transaction: TransactionWithRelations;
  evaluation: {
    decision: DecisionType;
    risk_score: number;
    risk_level: string;
    failed_checks: unknown[];
    passed_checks: unknown[];
    explanation: string;
    risk_factors: unknown[];
  };
  paymentEvents: PaymentEvent[];
  evidenceHash: string | null;
}

export async function simulateTransaction(input: SimulateTransactionInput): Promise<SimulateTransactionResult> {
  // Fetch related records
  const { data: auth } = await supabase.from('authorizations').select('*').eq('id', input.authorization_id).maybeSingle();
  const { data: agent } = await supabase.from('agents').select('*').eq('id', input.agent_id).maybeSingle();
  const { data: merchant } = await supabase.from('merchants').select('*').eq('id', input.merchant_id).maybeSingle();

  if (!auth || !agent || !merchant) {
    throw new Error('Failed to load authorization, agent, or merchant for simulation.');
  }

  // Get recent transactions for this agent
  const { data: recentTxs } = await supabase
    .from('transactions').select('*').eq('agent_id', input.agent_id);

  // Create transaction record
  const { data: tx, error: txError } = await supabase
    .from('transactions')
    .insert({
      authorization_id: input.authorization_id,
      agent_id: input.agent_id,
      user_id: auth.user_id,
      merchant_id: input.merchant_id,
      amount: input.amount,
      currency: input.currency,
      quantity: input.quantity,
      purpose: input.purpose,
      status: 'pending',
      decision: null,
    })
    .select()
    .maybeSingle();

  if (txError || !tx) {
    throw new Error('Failed to create transaction record.');
  }

  // Evaluate risk
  const evaluation = evaluateRisk({
    authorization: auth as Authorization,
    agent: agent as Agent,
    merchant: merchant as Merchant,
    transaction: tx as Transaction,
    recentTransactions: (recentTxs as Transaction[]) ?? [],
  });

  // Save risk decision
  const { data: savedDecision } = await supabase.from('risk_decisions').insert({
    transaction_id: tx.id,
    decision: evaluation.decision,
    risk_score: evaluation.risk_score,
    risk_level: evaluation.risk_level,
    failed_checks: evaluation.failed_checks,
    passed_checks: evaluation.passed_checks,
    explanation: evaluation.explanation,
    risk_factors: evaluation.risk_factors,
    ai_analysis: evaluation.ai_analysis,
  }).select().maybeSingle();

  // Save policy violations
  for (const fc of evaluation.failed_checks) {
    await supabase.from('policy_violations').insert({
      transaction_id: tx.id,
      check_name: fc.name,
      severity: fc.severity,
      expected: fc.expected,
      actual: fc.actual,
      message: fc.message,
    });
  }

  let paymentEvents: PaymentEvent[] = [];

  if (evaluation.decision === 'approved') {
    // Simulate payment
    const order = await razorpayService.createOrder({
      amount: tx.amount,
      currency: tx.currency,
      notes: { transaction_id: tx.id, purpose: tx.purpose },
    });

    const payment = await razorpayService.simulatePayment(order.order_id, tx.amount, tx.currency);
    const signature = `sig_mock_${order.order_id}_${payment.payment_id}`;
    const capture = await razorpayService.capturePayment(payment.payment_id, tx.amount, tx.currency);

    const eventTypes = [
      { type: 'order_created' as const, data: { razorpay_order_id: order.order_id, status: order.status, amount: order.amount, currency: order.currency } },
      { type: 'payment_initiated' as const, data: { razorpay_order_id: order.order_id, status: 'initiated', amount: tx.amount, currency: tx.currency } },
      { type: 'payment_success' as const, data: { razorpay_order_id: order.order_id, razorpay_payment_id: payment.payment_id, razorpay_signature: signature, status: payment.status, amount: tx.amount, currency: tx.currency } },
      { type: 'captured' as const, data: { razorpay_payment_id: payment.payment_id, status: capture.status, amount: capture.amount, currency: tx.currency } },
    ];

    for (const ev of eventTypes) {
      const eventData = razorpayService.buildPaymentEvent(tx.id, ev.type, ev.data);
      const { data: savedEv } = await supabase.from('payment_events').insert(eventData).select().maybeSingle();
      if (savedEv) paymentEvents.push(savedEv as PaymentEvent);
    }

    await supabase.from('transactions').update({ status: 'executed', decision: evaluation.decision }).eq('id', tx.id);
  } else {
    await supabase.from('transactions').update({ status: evaluation.decision, decision: evaluation.decision }).eq('id', tx.id);
  }

  // Generate evidence record
  const { data: userRecord } = await supabase.from('users').select('*').eq('id', auth.user_id).maybeSingle();
  const updatedTx = (await supabase.from('transactions').select('*').eq('id', tx.id).maybeSingle()).data as Transaction;

  const evidencePayload = {
    authorization: auth,
    agent: agent,
    user: userRecord as User,
    merchant: merchant,
    transaction: updatedTx,
    risk_decision: savedDecision as RiskDecision,
    payment_events: paymentEvents,
    timestamp: new Date().toISOString(),
    evidence_hash: '',
  };
  evidencePayload.evidence_hash = await computeEvidenceHash(evidencePayload);

  const { data: prevEvidence } = await supabase
    .from('evidence_records')
    .select('evidence_hash')
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  const previousHash = prevEvidence?.evidence_hash ?? 'GENESIS';
  const chainHash = await computeChainHash(evidencePayload.evidence_hash, previousHash);

  await supabase.from('evidence_records').insert({
    transaction_id: tx.id,
    evidence_hash: evidencePayload.evidence_hash,
    payload: evidencePayload,
    chain_hash: chainHash,
    previous_hash: previousHash,
    verified: true,
  });

  // Return enriched transaction
  const enriched = await enrichTransactions([updatedTx]);
  return {
    transaction: enriched[0],
    evaluation: {
      decision: evaluation.decision,
      risk_score: evaluation.risk_score,
      risk_level: evaluation.risk_level,
      failed_checks: evaluation.failed_checks,
      passed_checks: evaluation.passed_checks,
      explanation: evaluation.explanation,
      risk_factors: evaluation.risk_factors,
    },
    paymentEvents,
    evidenceHash: evidencePayload.evidence_hash,
  };
}

export async function verifyEvidence(recordId: string): Promise<boolean> {
  const { data: record } = await supabase
    .from('evidence_records')
    .select('*')
    .eq('id', recordId)
    .maybeSingle();
  if (!record) return false;

  const { verifyEvidenceIntegrity } = await import('@/lib/evidence');
  const isValid = await verifyEvidenceIntegrity(record as EvidenceRecord);
  // Evidence records are append-only: we do NOT update the verified flag in the database.
  // The verification result is returned to the caller for display only.
  return isValid;
}

export async function updateAgentStatus(agentId: string, status: 'active' | 'suspended'): Promise<void> {
  await supabase.from('agents').update({ status }).eq('id', agentId);
}

export async function updateAgentTrustScore(agentId: string, score: number): Promise<void> {
  await supabase.from('agents').update({ trust_score: score }).eq('id', agentId);
}

// ---------- Demo Scenarios ----------

export interface DemoScenario {
  id: string;
  title: string;
  description: string;
  expected: DecisionType;
  input: SimulateTransactionInput;
}

export const DEMO_SCENARIOS: DemoScenario[] = [
  {
    id: 'A',
    title: 'Legitimate Purchase',
    description: 'User authorizes laptop purchase up to ₹70,000. Agent proposes ₹64,999 from an allowed merchant.',
    expected: 'approved',
    input: {
      authorization_id: 'auth-001',
      agent_id: 'agent-001',
      merchant_id: 'merch-001',
      amount: 64999,
      currency: 'INR',
      quantity: 1,
      purpose: 'laptop_purchase',
    },
  },
  {
    id: 'B',
    title: 'Out-of-Scope Amount',
    description: 'User authorizes max ₹70,000. Agent proposes ₹82,000 — exceeds the limit.',
    expected: 'blocked',
    input: {
      authorization_id: 'auth-001',
      agent_id: 'agent-001',
      merchant_id: 'merch-001',
      amount: 82000,
      currency: 'INR',
      quantity: 1,
      purpose: 'laptop_purchase',
    },
  },
  {
    id: 'C',
    title: 'Suspicious Merchant',
    description: 'Within amount limit but merchant/category is unusual and high-risk.',
    expected: 'escalated',
    input: {
      authorization_id: 'auth-002',
      agent_id: 'agent-002',
      merchant_id: 'merch-006',
      amount: 18000,
      currency: 'INR',
      quantity: 2,
      purpose: 'office_supplies',
    },
  },
  {
    id: 'D',
    title: 'Agent Compromise',
    description: 'Amount and category are valid, but a different agent (QuickPay Agent) initiates the transaction using ShopAssist AI\'s authorization.',
    expected: 'blocked',
    input: {
      authorization_id: 'auth-001',
      agent_id: 'agent-004',
      merchant_id: 'merch-001',
      amount: 55000,
      currency: 'INR',
      quantity: 1,
      purpose: 'laptop_purchase',
    },
  },
];

export async function runDemoScenario(scenarioId: string): Promise<SimulateTransactionResult> {
  const scenario = DEMO_SCENARIOS.find((s) => s.id === scenarioId);
  if (!scenario) throw new Error('Unknown demo scenario.');
  return simulateTransaction(scenario.input);
}
